# 独立集 Token Jumping 求解器
在解压目录运行。实验环境为 Python 3.14.2 与 SciPy 1.18.1。

    python -m pip install scipy
    python -X utf8 正式实验/78_最终求解器.py 图.col 端点.dat --seconds 15 --output result.json
    python -X utf8 正式实验/78_最终求解器.py 图.col 端点.dat --verify result.json

图使用 CoRe 或 DIMACS 格式的 p 与 e 行，端点文件使用 s 与 t 行，顶点编号从 1 开始。
结果给出显式移动或压缩见证，亦可报告不可达或未判定。
使用 --family generic 处理任意图；--help 列出参数。
压缩格式的节点 0 表示空序列，move 的两个顶点采用一基编号，seq 和 root 使用零基节点下标。
压缩见证可用 --moves-out 写出显式移动。求解时无需模型和网络。

包内的模块按原有目录组织，无需复制实验文件。图和端点文件由调用者提供。

新版默认在同一预算内运行符合结构条件的带权展开及路径改短。
